#!/bin/sh
echo "user: $(whoami)"
echo "Dir:  $(pwd)"
date
