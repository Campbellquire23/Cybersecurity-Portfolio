text = "cybersecuritylearning"
print("length:", len(text))
print("lowercase:", text.lower())
print("uppercase:", text.upper())
slice_part = text[5:13]
print("sliced part:", slice_part)
index_of_learn = text.find("learning")
print("index of 'learning:", index_of_learn)
python3 string_methods.py
export_file sting_methods.py

